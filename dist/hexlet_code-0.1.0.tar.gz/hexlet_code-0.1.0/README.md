### Hexlet tests and linter status:
[![Actions Status](https://github.com/mbelveder/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/mbelveder/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/6782d3b6879fb613686b/maintainability)](https://codeclimate.com/github/mbelveder/python-project-49/maintainability)

### Usage examples:
- [brain-even](https://asciinema.org/a/yFpz0zS0fx12CdZWrlbd3pxUO)
- [brain-calc](https://asciinema.org/a/hwyChjqOheuYjJNP2QbvwI4yQ)