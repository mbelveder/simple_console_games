import prompt


def ask_question(question_subject):
    print(f'Question: {question_subject}')
    user_answer = prompt.string('Your answer: ')
    return user_answer


# def check_condition(right_answer, user_answer):
